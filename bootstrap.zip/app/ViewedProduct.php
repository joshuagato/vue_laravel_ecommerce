<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ViewedProduct extends Model
{
  protected $table = 'viewedproducts';
}
