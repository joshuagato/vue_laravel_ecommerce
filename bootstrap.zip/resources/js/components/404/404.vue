<template>
  <div class="error-page">
    <div class="code">404</div>
    <div class="message" style="padding: 10px;">Not Found</div>
</div>
</template>

<style lang="sass">
  .error-page
    height: 100vh
    width: 100%
    display: flex
    align-items: center
    justify-content: center
    font-weight: 100
    font-size: 26px
    color: #636b6f
  
  .code
    border-right: 3px solid #636b6f
    padding-right: 0.9rem

</style>